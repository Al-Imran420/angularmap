export interface Personnage {
    title: string,
    id?: number ,
    key: string,
    name: string,
    active?: boolean
}
